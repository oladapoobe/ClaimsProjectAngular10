
import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Claim } from 'src/app/model/claim';
import { Observable, throwError } from 'rxjs';
import { retry, catchError } from 'rxjs/operators';
import { environment } from 'src/environments/environment';
import { Response } from 'src/app/model/Response';
import Swal from 'sweetalert2/dist/sweetalert2.js';
import { claimType, EnumType } from '../../model/enum-type';
import { Policy } from '../../model/policy';
import { Policyidentifier } from '../../model/policyidentifier';
import { Documentclaim } from '../../model/document-claim';

@Injectable({
  providedIn: 'root'
})



export class ClaimsService {
  private readonly apiURL = `${environment.apiUrl}api/Claim`;
  private readonly apiURLCustomerType = `${environment.apiUrl}api/ClaimsType`;
  private readonly apiURLclaimdocuments = `${environment.apiUrl}api/ClaimDocuments`;
  private readonly apiURLPolicy = `${environment.apiUrl}api/Policy`;

  

  constructor(private http: HttpClient) { }

  

 
  UploadFile(data): Observable<Documentclaim> {
    console.log(data)
    return this.http.post<Documentclaim>(this.apiURLclaimdocuments + '/UploadFile/', data)
      .pipe(
        catchError(this.handleError)
      )
  }

  getrequireddocuments(data): Observable<EnumType> {
    return this.http.post<EnumType>(this.apiURLclaimdocuments + '/getrequireddocuments', data)
      .pipe(
        catchError(this.handleError)
      )
  }

  Getpolicybyidentifier(PlateNo, PolicyClass): Observable<Policyidentifier> {
    return this.http.get<Policyidentifier>(this.apiURLPolicy + '/Getpolicybyidentifier?PlateNo=' + PlateNo + '&PolicyClass=' + PolicyClass)
      .pipe(
        retry(1),
        catchError(this.handleError)
      )
  }



  Getpolicybypolicyid(PolicyID): Observable<Policy> {
    return this.http.get<Policy>(this.apiURLPolicy + '/Getpolicybypolicyid?PolicyID=' + PolicyID)
      .pipe(
        retry(1),
        catchError(this.handleError)
      )
  }

  GetCategory(): Observable<EnumType> {
    return this.http.get<EnumType>(this.apiURLCustomerType + '/CategoryType')
      .pipe(
        retry(1),
        catchError(this.handleError)
      )
  }


  // HttpClient API get() method =>
  getAllusername(username): Observable<Claim> {
    return this.http.get<Claim>(this.apiURL + '/get-all-claim-username/' + username)
      .pipe(
        retry(1),
        catchError(this.handleError)
      )
  }

  getAllDocumentType(): Observable<DocumentType> {
    return this.http.get<DocumentType>(this.apiURLclaimdocuments + '/DocumentType')
      .pipe(
        retry(1),
        catchError(this.handleError)
      )
  }

  getAllCurrency(): Observable<EnumType> {
    return this.http.get<EnumType>(this.apiURLclaimdocuments + '/Currency')
      .pipe(
        retry(1),
        catchError(this.handleError)
      )
  }

  getAllclaimtypes(): Observable<claimType> {
    return this.http.get<claimType>(this.apiURLCustomerType + '/getclaimtypes')
      .pipe(
        retry(1),
        catchError(this.handleError)
      )
  }

  getclaimtypesbyname(TypeName): Observable<claimType> {
    return this.http.get<claimType>(this.apiURLCustomerType + '/getclaimtypesbyname?TypeName=' + TypeName)
      .pipe(
        retry(1),
        catchError(this.handleError)
      )
  }

  

  getAllCustomerType(): Observable<EnumType> {
    
    return this.http.get<EnumType>(this.apiURLCustomerType + '/CustomerType' )
      .pipe(
        retry(1),
        catchError(this.handleError)
      )
  }

  // HttpClient API get() method =>
  getByID(id): Observable<Claim> {
    return this.http.get<Claim>(this.apiURL + '/role-by-id/' + id)
      .pipe(
        retry(1),
        catchError(this.handleError)
      )
  }

  // HttpClient API post() method => 
  create(data): Observable<Response> {
    return this.http.post<Response>(this.apiURL + '/post-create-claim', data)
      .pipe(

        catchError(this.handleError)
      )
  }

  // HttpClient API put() method => 
  update(id, data): Observable<Response> {
    return this.http.put<Response>(this.apiURL + '/put-update/' + id, data)
      .pipe(

        catchError(this.handleError)
      )
  }

  // HttpClient API delete() method => 
  DeleteFile(filePath) {
    return this.http.delete<Response>(this.apiURLclaimdocuments + '/DeleteFile?filePath=' + filePath)
      .pipe(

        catchError(this.handleError)
      )
  }

  // Error handling 
  handleError(error) {
    let errorMessage = '';
    if (error.error instanceof ErrorEvent) {
      // Get client-side error
      errorMessage = error.error.message;
    } else {
      // Get server-side error

      errorMessage = `Error Code: ${error.status}\nMessage: ${error.message}`;
    }
    Swal.fire('Please wait', 'Error in connecting to server, please contact Technology', 'error')

    return throwError(errorMessage);
  }

}
