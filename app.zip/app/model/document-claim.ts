export interface Documentclaim {

  fileName: string;
  fileUrl: string;
  id: string;
  ext: string;
  DateCreated: string;
  base64file: string;
  documentType: string;
}
