export interface EnumType {

  name: string;
  value: bigint;

}



export interface claimType {

  business: string;
  code: string;
  name: string;
  productSpec: string;
  type: string;

}


business: "NonMotor"
code: "Theft"
name: "All Risk "
productSpec: null
type: null
