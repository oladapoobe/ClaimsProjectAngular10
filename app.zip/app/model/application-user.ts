
export interface ApplicationUser {

  username: string;
  role: string;
  FullName: string;

}
