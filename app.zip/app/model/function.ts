export class Function {
  Id: bigint;
  IsEnabled: boolean;
  Name: string;
  Title: string;
  FunctionGroup: string;
  Description: string;
  Url: string;
}
