export interface Response {

responseCode: string;
responseMessage: string;
responseData: any;
}
