export interface Customer {

        PolicyKey : string;
        PolicyID : string;
        Name : string;
        PhoneNumber : string;
        TypeCode : string;
        CustomerType : string;
        Email : string;
        MobileNumber : string;
        Address : string;
        CustomerNo : string;
        Rank : string;
        Class : string;
}
