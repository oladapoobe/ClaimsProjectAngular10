import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-escalation-management',
  templateUrl: './escalation-management.component.html',
  styleUrls: ['./escalation-management.component.scss']
})
export class EscalationManagementComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
