import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Routes, RouterModule } from '@angular/router';
import { BackOfficeComponent } from './back-office.component';
import {EscalationManagementComponent} from './escalation-management/escalation-management.component';

const routes: Routes = [
  {
    path: '',
    component: BackOfficeComponent,
    children: [
      {
        path: '',
        redirectTo: 'escalationmanagement',
        pathMatch: 'full'
      },
      {
        path: 'escalationmanagement',
        component: EscalationManagementComponent
      },
    ]
  },
]

@NgModule({
  declarations: [BackOfficeComponent, EscalationManagementComponent],
  imports: [
    CommonModule,
    RouterModule.forChild(routes)
  ]
})
export class BackOfficeModule { }