import { ComponentFixture, TestBed } from '@angular/core/testing';
import { ClaimTATReportComponents } from './claim-tat-report.component';

describe('ClaimTATReportComponents', () => {
  let component: ClaimTATReportComponents;
  let fixture: ComponentFixture<ClaimTATReportComponents>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ClaimTATReportComponents ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ClaimTATReportComponents);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
