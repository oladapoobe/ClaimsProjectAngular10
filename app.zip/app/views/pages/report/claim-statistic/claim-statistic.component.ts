import { Component, OnInit } from '@angular/core';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';

@Component({
  selector: 'app-claims-statistic',
  templateUrl: './claim-statistic.component.html',
  styleUrls: ['./claim-statistic.component.scss']
})
export class ClaimStatisticComponent implements OnInit {

   constructor(private modalService: NgbModal) { }

  ngOnInit(): void {
  }

  openLgModal(content) {
    this.modalService.open(content, {size: 'lg'}).result.then((result) => {
      
    }).catch((res) => {});
  }

}
