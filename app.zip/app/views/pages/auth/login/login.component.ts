import { Component, OnInit, OnDestroy } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { AuthService } from 'src/app/service/auth-service/auth.service';
import { finalize } from 'rxjs/operators';
import { Subscription } from 'rxjs';
import { FormGroup, FormControl } from '@angular/forms';
import Swal from 'sweetalert2/dist/sweetalert2.js';


@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.scss']
})
export class LoginComponent implements OnInit, OnDestroy {

  LoginDetails = new FormGroup({
    username: new FormControl(''),
    password: new FormControl(''),
  })
  busy = false;

  private subscription: Subscription;
  UserName: any;
  FullName: any;

  constructor(
    private route: ActivatedRoute,
    private router: Router,
    private authService: AuthService
  ) { }

  returnUrl: any;

  ngOnInit(): void {
    this.subscription = this.authService.user$.subscribe((x) => {
      if (this.route.snapshot.url[0].path === 'login') {
        const accessToken = localStorage.getItem('access_token');
        const refreshToken = localStorage.getItem('refresh_token');
        if (x && accessToken && refreshToken) {

        }
      } // optional touch-up: if a tab shows login page, then refresh the page to reduce duplicate login
    });
  }

  login() {

    Swal.fire('Please wait', "Authentication in progress", 'warning')
    Swal.showLoading();

      if (!this.LoginDetails.value.username || !this.LoginDetails.value.password) {
        Swal.fire('Sorry...', "your username and password is invalid", 'error')
        return;
      }

      this.busy = true;
      const returnUrl = this.route.snapshot.queryParams['returnUrl'] || '';
      this.authService
        .login(this.LoginDetails.value.username, this.LoginDetails.value.password)

        .pipe(finalize(() => (this.busy = false)))
        .subscribe(
          () => {
         
            this.FullName = localStorage.getItem('FullName');
            Swal.fire('Welcome ' + this.FullName, "Authentication Successfull", 'success')
            
            this.router.navigate([returnUrl]);
          },
          () => {
            this.UserName = localStorage.getItem('UserName');
            if (localStorage.getItem('access_token') == 'undefined') {
              Swal.fire('Sorry...', this.UserName, 'error')
            }
          
          }
        );
   


  
  }

  ngOnDestroy(): void {
    this.subscription?.unsubscribe();
  }
}






