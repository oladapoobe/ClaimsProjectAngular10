import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-new-function',
  templateUrl: './new-function.component.html',
  styleUrls: ['./new-function.component.scss']
})
export class NewFunctionComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
