import { Component, OnInit } from '@angular/core';
import { UserService } from "src/app/service/user-service/user.service";
import { FormGroup, FormControl } from '@angular/forms';
import Swal from 'sweetalert2/dist/sweetalert2.js';
import { UserResponse } from 'src/app/model/user';
import { ColumnMode } from '@swimlane/ngx-datatable';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { RoleService } from 'src/app/service/role-service/role.service';


@Component({
  selector: 'app-all-user',
  templateUrl: './all-user.component.html',
  styleUrls: ['./all-user.component.scss']
})
export class AllUserComponent implements OnInit {

  //dtOptions: any = {};
  dtOptions: DataTables.Settings = {};

  rows: any = [];
  RoleList: any = [];
  loadingIndicator = true;
  reorderable = true;
  ColumnMode = ColumnMode;


  username: any;
  role: any;
  name: any;
  isEnabled: any;
  dateCreated: any;

  constructor(public ApiAction: UserService, private modalService: NgbModal, public ApiRoleAction: RoleService) { }

  ngOnInit(): void {


    Swal.fire('Please wait', "geting all user record progress", 'warning')
    Swal.showLoading();

    this.ApiRoleAction.getAll().subscribe((datarole: {}) => {
      this.RoleList = datarole;
      this.ApiAction.getAll().subscribe((data: {}) => {
        this.rows = data;
        console.log(this.rows);
        setTimeout(() => {
          this.loadingIndicator = false;
        }, 1500);

        Swal.close();

      })

    })

  }

  basicModalCloseResult: string = '';
  openBasicModal(content, rowval) {

   this.username = rowval.username;
   const rolesearch = this.RoleList.filter(x => x.id == rowval.id)

   this.role = rolesearch.length == 0 ? "Not found" : rolesearch[0].name;

   this.name = rowval.name;
   this.isEnabled = rowval.isEnabled;
   this.dateCreated = rowval.dateCreated;

    this.modalService.open(content, {}).result.then((result) => {
      this.basicModalCloseResult = "Modal closed" + result
    }).catch((res) => { });
  }

  



}
