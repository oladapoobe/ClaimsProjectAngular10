import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-claim-list',
  templateUrl: './claim-list.component.html',
  styleUrls: ['./claim-list.component.scss']
})
export class ClaimListComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
