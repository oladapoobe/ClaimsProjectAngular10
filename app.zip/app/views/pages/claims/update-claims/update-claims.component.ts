import { Component, OnInit } from '@angular/core';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { ClaimsService } from 'src/app/service/claims-service/claims.service';
import { NgbDateStruct, NgbCalendar, NgbDate, NgbDateParserFormatter } from '@ng-bootstrap/ng-bootstrap';
import { FormGroup, FormControl } from '@angular/forms';
import Swal from 'sweetalert2/dist/sweetalert2.js';
import { ColumnMode } from '@swimlane/ngx-datatable';

@Component({
  selector: 'app-update-claims',
  templateUrl: './update-claims.component.html',
  styleUrls: ['./update-claims.component.scss']
})
export class UpdateClaimComponent implements OnInit {
  selectedDate: NgbDateStruct;

  UserDetails = new FormGroup({
    Sbu: new FormControl(''),
    Name: new FormControl(''),
    Username: new FormControl(''),
    RoleId: new FormControl(''),
  });

  constructor(private modalService: NgbModal,
    public apiClaimAction: ClaimsService) { }

  rows: any = [];
  loadingIndicator = true;
  reorderable = true;
  ColumnMode = ColumnMode;



  ngOnInit(): void {
    Swal.fire('Please wait', "geting all claims artifact in progress", 'warning')
    Swal.showLoading();

    //this.apiClaimAction.getAll().subscribe((datarole: {}) => {
    //  this.rows = datarole;

    //  setTimeout(() => {
    //    this.loadingIndicator = false;
    //  }, 1500);
    //  Swal.close();



    //})
    Swal.close();
  }



}
