import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-my-claims',
  templateUrl: './my-claims.component.html',
  styleUrls: ['./my-claims.component.scss']
})
export class MyClaimsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }
}