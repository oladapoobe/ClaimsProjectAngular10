import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Routes, RouterModule } from '@angular/router';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { AllClaimComponent } from './all-claims/all-claims.component';
import { UpdateClaimComponent } from './update-claims/update-claims.component';
import { NotifyClaimComponent } from './notify-claims/notify-claims.component';
import { MyClaimsComponent } from './my-claims/my-claims.component';
import { ClaimsComponent } from './claims.component';
import {ClaimTrackingComponent} from './claim-tracking/claim-tracking.component';
import {ClaimListComponent} from './claim-list/claim-list.component';
import { NgxDatatableModule } from '@swimlane/ngx-datatable';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';

const routes: Routes = [
  {
    path: '',
    component: ClaimsComponent,
    children: [
      {
        path: '',
        redirectTo: 'allclaims',
        pathMatch: 'full'
      },
      {
        path: 'allclaims',
        component: AllClaimComponent
      },
      {
        path: 'notifyclaims',
        component: NotifyClaimComponent
      },
      {
        path: 'updateclaims',
        component: UpdateClaimComponent
      },
      {
        path: 'myclaims',
        component: MyClaimsComponent
      },
      {
        path: 'claimtracking',
        component: ClaimTrackingComponent
      },
      {
        path: 'claimlist',
        component: ClaimListComponent
      }
    ]
  },
]

@NgModule({
  declarations: [AllClaimComponent, MyClaimsComponent, NotifyClaimComponent, UpdateClaimComponent, ClaimsComponent, ClaimTrackingComponent, ClaimListComponent],
  imports: [
    CommonModule,
    RouterModule.forChild(routes),
    NgxDatatableModule,
    ReactiveFormsModule,
    NgbModule,
    FormsModule
    
  ]
})
export class ClaimsModule { }





