import { MenuItem } from './menu.model';

export const MENU: MenuItem[] = [
  {
    label: 'Main',
    isTitle: true
  },
  {
    label: 'Dashboard',
    icon: 'home',
    link: '/dashboard'
  },
   
  {
    label: 'Administration',
    icon: 'file-text',
    subItems: [
      {
        label: 'User Management',
        subItems: [
          {
            label: 'new-user',
            link: '/user-management/new-user'
          },
          {
            label: 'all users',
            link: '/user-management/all-user'
          },
        ],
      },
      {
        label: 'Role Management',
        subItems: [
          {
            label: 'New Role',
            link: '/user-management/new-role'
          },
          {
            label: 'All Roles',
            link: '/user-management/all-role'
          },
        ]
      },
      {
        label: 'Function Management',
        subItems: [
          {
            label: 'New Function',
            link: '/user-management/new-function'
          },
          {
            label: 'All Functions',
            link: '/user-management/all-function'
          },
        ]
      },
      {
        label: 'Approval Management',
        subItems: [
          {
            label: 'User Approval',
            link: '/User-Approval'
          },
          {
            label: 'User Role-Approval',
            link: '/User-Role-Approval'
          },
          {
            label: 'User Function-Approval',
            link: '/User-Function-Approval'
          },
          {
            label: 'User Role-Function-Approval',
            link: '/User-Role-Function-Approval'
          },
          {
            label: 'Claims Approval',
            link: '/Claims-Approval'
          },
          {
            label: 'Claims Approval(Individual)',
            link: '/Claims-Approval-Individual'
          },
          {
            label: 'Claims Approval(Role)',
            link: '/Claims-Approval-Role'
          },
          {
            label: 'Pay Claims(TSU)',
            link: '/Pay-Claims-TSU'
          },
          {
            label: 'Download Claims PF(TSU)',
            link: '/Download-Claims-PF-TSU'
          },
          {
            label: 'Re-Assign Claims',
            link: '/Re-Assign-Claims'
          },
        ]
      },
      {
        label: 'Audit Trail',
        subItems: [
          {
            label: 'All Audit Trail',
            link: '/All-Audit-Trail'
          },
        ]
      },
    ],

  },

  {
    label: 'Claims',
    icon: 'file-text',
    subItems: [
      {
        label: 'Retail Claim',
        subItems: [
          {
            label: 'Notify Claim',
            link: '/claims/notifyclaims'
          },
          {
            label: 'Update Claim',
            link: '/claims/updateclaims'
          },
          {
            label: 'All Claims',
            link: '/claims/allclaims'
          },
          {
            label: 'My Claim',
            link: '/claims/myclaims'
          },
        ],
      },
      {
        label: 'Claim Tracking',
        subItems: [
          {
            label: 'Claim Tracking',
            link: '/claims/claimtracking'
          },
          {
            label: 'Claim List',
            link: '/claims/claimlist'
          },
        ]
      },
    ],
  },

  {
    label: 'Back Office',
    icon: 'file-text',
    subItems: [
      {
        label: 'Escalation Management',
        link: '/backoffice/escalationmanagement'
      },
    ]
  },


  {
    label: 'Configuration',
    icon: 'file-text',
    subItems: [
      {
        label: 'Category Config',
        subItems: [
          {
            label: 'New Category',
            link: '/New-Category'
          },
          {
            label: 'All Category',
            link: '/All-Category'
          },
          {
            label: 'Mapping Configuration',
            link: '/Mapping-Configuration'
          },
          {
            label: 'Mapping Approval',
            link: '/Mapping-Approval'
          },
        ],
      },
      {
        label: 'Vendor Management',
        subItems: [
          {
            label: 'New Vendor',
            link: '/New-Vendor'
          },
          {
            label: 'All Vendor',
            link: '/All-Vendor'
          },
        ]
      },

    ],

  },


  {
    label: 'Reports',
    icon: 'file-text',
    subItems: [
      {
        label: 'Claim Report',
        subItems: [
          {
            label: 'Claim TAT Report',
            link: '/report/claimtatreport'
          },
        ]
      },
      {
        label: 'Card Statistic',
        subItems: [
          {
            label: 'Claim Statistic',
            link: '/report/claimstatistic'
          },
        ]
      },
      {
        label: 'Activated Cards Report',
        subItems: [
          {
            label: 'Completed Claims Report',
            link: '/report/completedclaimreport'
          },
        ]
      },
      {
        label: 'Card Request Tracker',
        subItems: [
          {
            label: 'Claim Tracker',
            link: '/report/claimtracker'
          },
        ]
      },
    ]
  }
];
