export interface Policy {
  PolicyID: string;
  PolicyKey: string;
  CustomerNo: string;
  Identifier: string;
  StartDate: string;
  EndDate: string;
  Product: string;
  Make: string;
  Branch: string;
  Office: string;
  SBU: string;
  BusinessType: string;
  SumInsured: string;
  Premium: string;
}


