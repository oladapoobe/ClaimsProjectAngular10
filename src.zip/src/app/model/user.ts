
export interface User {

  Id: bigint;
  IsEnabled: boolean;
  DateCreated: string;
  Name: string;
  Username: string;
  Axaunit: string;
  RoleId: bigint;
  IsLockedOut: boolean;
  LastLoginDate: string;
  FailedLoginAttempts: bigint;
  Sbu: string;

}

export interface RequestUser {
  IsEnabled: boolean;
  Name: string;
  Username: string;
  Axaunit: string;
  RoleId: bigint;
  Sbu: string;
}

export interface VerifyUser {
  name: string;
  username: string;
}

export interface VerifiedUser {
  responseCode: string;
  responseMessage: string;
  responseData: VerifyUser
}

export interface UserResponse {
  name: string;
  username: string;
  roleId: bigint;
  sbu: string;
  lastLoginDate: string;
  isLockedOut: boolean;
  failedLoginAttempts: bigint;
  dateCreated: string;
  isEnabled: boolean;
  roleName: string;
}



