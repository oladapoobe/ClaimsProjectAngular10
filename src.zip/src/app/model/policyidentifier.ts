import { Customer } from './customer';
import { Policy } from './policy';

export interface Policyidentifier {

  custClass: string;
  startDate: string;
  endDate: string;
  custDetails: Customer;
  policy :Policy

}
