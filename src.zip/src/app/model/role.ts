export interface Role {
  Id: bigint;
  DateCreated: string;
  IsEnabled: boolean;
  Name: string;
  Description: string;
  IsSuperAdmin: boolean;
  TransactionLimitId: bigint;
  TransactionLimit: number;
  CanTransact: boolean;
}



