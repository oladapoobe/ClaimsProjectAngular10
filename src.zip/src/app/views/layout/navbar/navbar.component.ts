import { Component, OnInit, ViewChild, ElementRef, Inject, Renderer2 } from '@angular/core';
import { DOCUMENT } from '@angular/common';
import { Router } from '@angular/router';
import { AuthService } from "src/app/service/auth-service/auth.service";

@Component({
  selector: 'app-navbar',
  templateUrl: './navbar.component.html',
  styleUrls: ['./navbar.component.scss']
})
export class NavbarComponent implements OnInit {

  UserName: any;
  Role: any;
  FullName: any;

  constructor(
    @Inject(DOCUMENT) private document: Document, 
    private renderer: Renderer2,
    private router: Router,
    public ApiAction: AuthService,
  ) { }

  ngOnInit(): void {
    this.UserName = localStorage.getItem('UserName');
    this.Role = localStorage.getItem('Role');
    this.FullName = localStorage.getItem('FullName');

  }

  /**
   * Sidebar toggle on hamburger button click
   */
  toggleSidebar(e) {
    e.preventDefault();
    this.document.body.classList.toggle('sidebar-open');
  }

  /**
   * Logout
   */
  onLogout(e) {
    e.preventDefault();

    this.ApiAction.logout();
    this.router.navigate(['/auth/login']);
    
  }

}
