import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { AllUserComponent } from './all-user/all-user.component';
import { NewUserComponent } from './new-user/new-user.component';
import { Routes, RouterModule } from '@angular/router';
import { UserManagementComponent } from './user-management.component';
import { ReactiveFormsModule } from '@angular/forms';
import { DataTablesModule } from 'angular-datatables';
import { NgxDatatableModule } from '@swimlane/ngx-datatable';
import { AllRoleComponent } from './all-role/all-role.component';
import { NewRoleComponent } from './new-role/new-role.component';
import { AllFunctionComponent } from './all-function/all-function.component';
import { NewFunctionComponent } from './new-function/new-function.component';


const routes: Routes = [
  {
    path: '',
    component: UserManagementComponent,
    children: [
      {
        path: '',
        redirectTo: 'all-user',
        pathMatch: 'full'
      },
      {
        path: 'all-user',
        component: AllUserComponent
      },
      {
        path: 'new-user',
        component: NewUserComponent
      },
      {
        path: 'new-role',
        component: NewRoleComponent
      },
      {
        path: 'all-role',
        component: AllRoleComponent
      },
      {
        path: 'new-function',
        component: NewFunctionComponent
      },
      {
        path: 'all-function',
        component: AllFunctionComponent
      },

    ]
  },
]


@NgModule({
  declarations: [AllUserComponent, UserManagementComponent, NewUserComponent, AllRoleComponent, NewRoleComponent, AllFunctionComponent, NewFunctionComponent],
  imports: [
    CommonModule,
    RouterModule.forChild(routes),
    ReactiveFormsModule,
    DataTablesModule,
    NgxDatatableModule
    
  ]
})
export class UserManagementModule { }
