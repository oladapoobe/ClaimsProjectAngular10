import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl } from '@angular/forms';
import { UserService } from "src/app/service/user-service/user.service";
import Swal from 'sweetalert2/dist/sweetalert2.js';
import { VerifiedUser } from 'src/app/model/user';
import { RequestUser } from 'src/app/model/user';
import { RoleService } from 'src/app/service/role-service/role.service';

@Component({
  selector: 'app-new-user',
  templateUrl: './new-user.component.html',
  styleUrls: ['./new-user.component.scss']
})
export class NewUserComponent implements OnInit {

  UserDetails = new FormGroup({
    Sbu: new FormControl(''),
    Name: new FormControl(''),
    Username: new FormControl(''),
    RoleId: new FormControl(''),
  });

  VerifyDetails = new FormGroup({
    Username: new FormControl(''),
  });

  loaddata: RequestUser;
  RoleList: any = [];
  constructor(public ApiAction: UserService, public ApiRoleAction: RoleService) { }

  ngOnInit(): void {
    Swal.fire('Loading please wait...', "in progress", 'warning')
    Swal.showLoading();
    this.ApiRoleAction.getAll().subscribe((data: {}) => {
      this.RoleList = data;

      Swal.close();
    })
  }

  Create() {
    Swal.fire({
      title: 'Are you sure?',
      text: "You want to create this user!",
      icon: 'warning',
      showCancelButton: true,
      confirmButtonColor: '#3085d6',
      cancelButtonColor: '#d33',
      confirmButtonText: 'Yes, Create it!'
    }).then((result) => {
      if (result.isConfirmed) {
        
        Swal.fire('Please wait', "Creating user in progress", 'warning');
    
        Swal.showLoading();
        this.UserDetails.controls['Username'].patchValue(this.VerifyDetails.value.Username);
        this.ApiAction.create(this.UserDetails.value).subscribe(data => {

          if (data.responseCode == "00") {
            Swal.fire('Thank you...', data.responseMessage, 'success');
          } else {
            Swal.fire('Sorry...', data.responseMessage, 'error');
          }
        })
      }
    })
  }

  changeWebsite(e) {
    console.log(this.UserDetails.value.RoleId);

    
  }

  Verify() {
    Swal.fire({
      title: 'Are you sure?',
      text: "You want to verify this user!",
      icon: 'warning',
      showCancelButton: true,
      confirmButtonColor: '#3085d6',
      cancelButtonColor: '#d33',
      confirmButtonText: 'Yes, verify!'
    }).then((result) => {
      if (result.isConfirmed) {


        Swal.fire('Please wait', "Verfication in progress", 'warning')
        Swal.showLoading();
        this.ApiAction.verify(this.VerifyDetails.value.Username).subscribe((data: VerifiedUser) => {

          console.log(data);
          if (data.responseCode == "00") {
            Swal.fire('Thank you...', data.responseMessage, 'success');
            this.UserDetails.controls['Name'].patchValue(data.responseData.name);
        

          } else {
            Swal.fire('Thank you...', data.responseMessage, 'error');
        }

        })
      }
    })
  }

}
