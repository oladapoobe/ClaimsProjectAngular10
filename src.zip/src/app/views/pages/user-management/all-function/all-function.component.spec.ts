import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AllFunctionComponent } from './all-function.component';

describe('AllFunctionComponent', () => {
  let component: AllFunctionComponent;
  let fixture: ComponentFixture<AllFunctionComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AllFunctionComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(AllFunctionComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
