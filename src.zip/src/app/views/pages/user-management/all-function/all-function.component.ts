

import { Component, OnInit } from '@angular/core';
import { UserService } from "src/app/service/user-service/user.service";
import { FormGroup, FormControl } from '@angular/forms';
import Swal from 'sweetalert2/dist/sweetalert2.js';
import { UserResponse } from 'src/app/model/user';
import { ColumnMode } from '@swimlane/ngx-datatable';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { FunctionService } from 'src/app/service/function-service/function.service';


@Component({
  selector: 'app-all-function',
  templateUrl: './all-function.component.html',
  styleUrls: ['./all-function.component.scss']
})
export class AllFunctionComponent implements OnInit {

  //dtOptions: any = {};
  dtOptions: DataTables.Settings = {};

  rows: any = [];
  loadingIndicator = true;
  reorderable = true;
  ColumnMode = ColumnMode;


  name: any;
  title: any;
  functionGroup: any;
  url: any;
  description: any;
  IsEnabled: any;

  constructor(public ApiAction: UserService, private modalService: NgbModal, public ApifunctionAction: FunctionService) { }

  ngOnInit(): void {


    Swal.fire('Please wait', "geting all record in progress", 'warning')
    Swal.showLoading();

    this.ApifunctionAction.getAll().subscribe((data: {}) => {
      this.rows = data;
        setTimeout(() => {
          this.loadingIndicator = false;
        }, 1500);

        Swal.close();

      

    })

  }

  basicModalCloseResult: string = '';
  openBasicModal(content, rowval) {


    this.name = rowval.name;
    this.title = rowval.title;
    this.functionGroup = rowval.functionGroup;
    this.url = rowval.url;
    this.description = rowval.description;
    this.IsEnabled = rowval.isEnabled;

    this.modalService.open(content, {}).result.then((result) => {
      this.basicModalCloseResult = "Modal closed" + result
    }).catch((res) => { });
  }





}
