




import { Component, OnInit } from '@angular/core';
import { UserService } from "src/app/service/user-service/user.service";
import { FormGroup, FormControl } from '@angular/forms';
import Swal from 'sweetalert2/dist/sweetalert2.js';
import { UserResponse } from 'src/app/model/user';
import { ColumnMode } from '@swimlane/ngx-datatable';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { RoleService } from 'src/app/service/role-service/role.service';


@Component({
  selector: 'app-all-role',
  templateUrl: './all-role.component.html',
  styleUrls: ['./all-role.component.scss']
})
export class AllRoleComponent implements OnInit {

  //dtOptions: any = {};
  dtOptions: DataTables.Settings = {};

  rows: any = [];
  loadingIndicator = true;
  reorderable = true;
  ColumnMode = ColumnMode;


  name: any;
  description: any;
  IsEnabled: any;
  IsSuperAdmin: any;

  constructor(public ApiAction: UserService, private modalService: NgbModal, public ApiRoleAction: RoleService) { }

  ngOnInit(): void {


    Swal.fire('Please wait', "geting all role record in progress", 'warning')
    Swal.showLoading();

    this.ApiRoleAction.getAll().subscribe((datarole: {}) => {
      this.rows = datarole;

        setTimeout(() => {
          this.loadingIndicator = false;
        }, 1500);
        Swal.close();

      

    })

  }

  basicModalCloseResult: string = '';
  openBasicModal(content, rowval) {

   
    this.name = rowval.name;
    this.description = rowval.description;
    this.IsEnabled = rowval.IsEnabled;
    this.IsSuperAdmin = rowval.IsSuperAdmin;

    this.modalService.open(content, {}).result.then((result) => {
      this.basicModalCloseResult = "Modal closed" + result
    }).catch((res) => { });
  }





}
