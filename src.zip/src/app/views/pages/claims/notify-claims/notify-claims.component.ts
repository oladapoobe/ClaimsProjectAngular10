import { Component, OnInit, ViewChild } from '@angular/core';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { ClaimsService } from 'src/app/service/claims-service/claims.service';
import { NgbDateStruct, NgbCalendar, NgbDate, NgbDateParserFormatter } from '@ng-bootstrap/ng-bootstrap';
import { FormGroup, FormControl } from '@angular/forms';
import Swal from 'sweetalert2/dist/sweetalert2.js';
import { ColumnMode, isNullOrUndefined } from '@swimlane/ngx-datatable';
import { Policy } from '../../../../model/policy';
import { Policyidentifier } from '../../../../model/policyidentifier';
import { HttpHeaders } from '@angular/common/http';


@Component({
  selector: 'app-notify-claims',
  templateUrl: './notify-claims.component.html',
  styleUrls: ['./notify-claims.component.scss']
})
export class NotifyClaimComponent implements OnInit {
  @ViewChild('myInput')
  myInputVariable: any;

  claimsDetails = new FormGroup({
    Id: new FormControl(''),
    DateCreated: new FormControl(''),
    IsEnabled: new FormControl(''),
    DateLastModified: new FormControl(''),
    Name: new FormControl(''),
    CustomerNumber: new FormControl(''),
    PolicyId: new FormControl(''),
    PolicyKey: new FormControl(''),
    ClaimKey: new FormControl(''),
    VehicleRegistrationNumber: new FormControl(''),
    Details: new FormControl(''),
    CustomerName: new FormControl(''),
    Product: new FormControl(''),
    DateOfLoss: new FormControl(''),
    FixByUs: new FormControl(''),
    Location: new FormControl(''),
    ModEstimateValue: new FormControl(''),
    EstimateValue: new FormControl(''),
    AdjustersValue: new FormControl(''),
    AdjustersRemark: new FormControl(''),
    DeclineReason: new FormControl(''),
    Status: new FormControl(''),
    TrackingNumber: new FormControl(''),
    TotalAmount: new FormControl(''),
    ExpectedResponseTime: new FormControl(''),
    HasTp: new FormControl(''),
    ClaimType: new FormControl(''),
    CategoryId: new FormControl(''),
    AssignedProcessorId: new FormControl(''),
    CustomerType: new FormControl(''),
    ClaimClass: new FormControl(''),
    CustomerAccountNumber: new FormControl(''),
    BankId: new FormControl(''),
    HasBeenDownloaded: new FormControl(''),
    IsChequePayment: new FormControl(''),
    ChequeNumber: new FormControl(''),
    TransferType: new FormControl(''),
    BatchId: new FormControl(''),
    CreditNoteId: new FormControl(''),
    Beneficiary: new FormControl(''),
    CreatedBy: new FormControl(''),
    LastModifiedBy: new FormControl(''),
    Pay: new FormControl(''),
    Sbucode: new FormControl(''),
    ReceiptId: new FormControl(''),
    CustomerClass: new FormControl(''),
    Ranking: new FormControl(''),
    Source: new FormControl(''),
    EstimatedRepairDate: new FormControl(''),
    IsPaid: new FormControl(''),
    Currency: new FormControl(''),
    ArchiveId: new FormControl(''),
    Survey: new FormControl(''),

  });

  claimsDocument = new FormGroup({
    Name: new FormControl(''),
    ClaimId: new FormControl(''),
    DocImage: new FormControl(''),
    Description: new FormControl(''),
    DocumentType: new FormControl(''),
    FileType: new FormControl(''),
    IsUploaded: new FormControl(''),
  });

  //change
  SearchUserClaims = new FormGroup({
    searchCriteria: new FormControl(''),
    searchKey: new FormControl(''),
    policyClass: new FormControl(''),

  });
  DocumentSearchParams = new FormGroup({
    ClaimID: new FormControl(''),
    Band: new FormControl(''),
    EnumType: new FormControl(''),
    ProductName: new FormControl(''),
    CustomerType: new FormControl(''),
  });

  // UploadDocumentfile = new FormGroup({
  //   base64file: new FormControl(''),
  //   docfilename: new FormControl(''),
  //   docfiletype: new FormControl(''),
  // });



  name: any;
  custClass: any;
  policyKey: any;
  policy: any;
  DateofLoss: any;
  enddate: any;
  email: any;
  mobileNumber: any;



  UserName: any;
  rows: any = [];
  CategoryTyeperows: any = [];
  DocumentTyperows: any = [];
  Currencyrows: any = [];
  claimtypesrows: any = [];
  CustomerTyperows: any = [];
  ClaimTypebyproduct: any = [];
  loadingIndicator = true;
  reorderable = true;
  ColumnMode = ColumnMode;
  UploadDocumentfile: any = [];
  policyView: any;
  CusPolicyList: any = [];
  base64filecount: any;
  DocumentListrows: any = [];
  DocumentListDatas: any = [] ;

  constructor(private modalService: NgbModal,
    public apiClaimAction: ClaimsService) { }

  ngOnInit(): void {
    Swal.fire('Please wait', "loading all claims artifact in progress", 'warning')
    Swal.showLoading();

    this.UserName = localStorage.getItem('UserName');
    this.apiClaimAction.getAllusername(this.UserName).subscribe((a: {}) => {
      this.DocumentTyperows = a;

      this.apiClaimAction.getAllclaimtypes().subscribe((d: {}) => {
        this.claimtypesrows = d;

        this.apiClaimAction.getAllCurrency().subscribe((c: {}) => {
          this.Currencyrows = c;
      


          this.apiClaimAction.getAllCustomerType().subscribe((e: {}) => {
            this.CustomerTyperows = e;

            this.apiClaimAction.GetCategory().subscribe((f: {}) => {
              this.CategoryTyeperows = f;


              Swal.close();


            })
          })
        })
      })
    })
  }


  openFileBrowser(event: any) {
    event.preventDefault();
    let element: HTMLElement = document.querySelector("#fileUploadInputExample") as HTMLElement;
    element.click()
  }

  handleFileInput(event: any) {
    if (event.target.files.length) {
      let element: HTMLElement = document.querySelector("#fileUploadInputExample + .input-group .file-upload-info") as HTMLElement;
      let fileName = event.target.files[0].name;
      element.setAttribute('value', fileName)
    }
  }

  basicModalCloseResult: string = '';
  Search(content) {


    Swal.fire('Please wait', "searching criteria...", 'warning')
    Swal.showLoading();

    this.apiClaimAction.getclaimtypesbyname(this.SearchUserClaims.value.policyClass).subscribe((x: {}) => {

      console.log(x);
      this.ClaimTypebyproduct = x;

      if (this.SearchUserClaims.value.searchCriteria == "Plate NO") {
        this.apiClaimAction.Getpolicybyidentifier(this.SearchUserClaims.value.searchKey, this.SearchUserClaims.value.policyClass).subscribe((data: {}) => {

          this.policyView = data;
          this.name = this.policyView.custDetails.name;
          this.custClass = this.policyView.custClass;
          this.policyKey = this.policyView.policy.policyKey;
          this.policy = this.policyView.policy.identifier;
          this.enddate = this.policyView.endDate;
          this.email = this.policyView.custDetails.email;
          this.mobileNumber = this.policyView.custDetails.customerNo;
          console.log(this.policyView);
          Swal.close();


        })
      } else if (this.SearchUserClaims.value.searchCriteria == "Policy ID/Key") {
        this.apiClaimAction.Getpolicybypolicyid(this.SearchUserClaims.value.searchKey).subscribe((data: {}) => {
          this.CusPolicyList = data;
          this.modalService.open(content, {}).result.then((result) => {
            this.basicModalCloseResult = "Modal closed" + result
          }).catch((res) => { });
          Swal.close()

        })
      } else {
        Swal.fire('Invalid...', "Kindly select a search Criteria", 'error');
      }


    })

  }

  Create() {
    Swal.fire({
      title: 'Are you sure',
      text: "You want to create this claims!",
      icon: 'warning',
      showCancelButton: true,
      confirmButtonColor: '#3085d6',
      cancelButtonColor: '#d33',
      confirmButtonText: 'Yes, Create it!'
    }).then((result) => {
      if (result.isConfirmed) {

        Swal.fire('Please wait', "Creating claims in progress", 'warning');

        Swal.showLoading();
        console.log(this.claimsDetails.value);
        this.apiClaimAction.create(this.claimsDetails.value).subscribe(data => {

          if (data.responseCode == "00") {
            Swal.fire('Thank you...', data.responseMessage, 'success');
          } else {
            Swal.fire('Sorry...', data.responseMessage, 'error');
          }
        })
      }
    })
  }

  onKeyUpEvent() {
    this.DocumentSearchParams.controls['ProductName'].patchValue(this.SearchUserClaims.value.policyClass);
    this.DocumentSearchParams.controls['ClaimID'].patchValue(null);
    this.DocumentSearchParams.controls['Band'].patchValue(this.claimsDetails.value.EstimateValue);
    this.DocumentSearchParams.controls['EnumType'].patchValue(this.custClass);
    this.DocumentSearchParams.controls['CustomerType'].patchValue(this.claimsDetails.value.CustomerType);


    this.apiClaimAction.getrequireddocuments(this.DocumentSearchParams.value).subscribe(data => {
      this.DocumentTyperows = data;
    })


  }


  uploadFile(event) {
    this.UploadDocumentfile =[]
    var files = event.target.files;
    Swal.fire('Please wait', "selecting file in progress", 'warning');

    Swal.showLoading();
    this.base64filecount = 0;
    for (let i = 0; i < files.length; i++) {

      const reader = new FileReader();
      reader.onload = (e: any) => {

        const imgBase64Path = e.target.result;
        var docfiletype = files[i].type;
        var docfilename = files[i].name;
        var filetype = docfilename.split('.');

        console.log(filetype);

        var mediafiles = [{ foo: 'pdf' }, { foo: 'jpg' }, { foo: 'jpeg' }, { foo: 'png' }, { foo: 'bmp' }];
        var checktype = mediafiles.filter(x => x.foo == filetype[1]);
        if (checktype.length > 0) {

          if (this.claimsDocument.value.DocumentType !== "") {

            this.UploadDocumentfile.push({ "base64file": imgBase64Path, "docfilename": docfilename, "docfiletype": docfiletype, "documentType": this.claimsDocument.value.DocumentType })
            this.base64filecount = this.base64filecount + 1;

          }
          else {
            Swal.fire('sorry', "kindly select document type", 'error');
            this.myInputVariable.nativeElement.value = "";
            this.claimsDocument = new FormGroup({
              Name: new FormControl(''),
              ClaimId: new FormControl(''),
              DocImage: new FormControl(''),
              Description: new FormControl(''),
              DocumentType: new FormControl(''),
              FileType: new FormControl(''),
              IsUploaded: new FormControl(''),
            });
            // element.value = '';
          }
        } else {
          Swal.fire('sorry', "uploaded file contained an unsupported media file" + ":" + docfiletype + " List of supported media files: " +  "pdf, jpg, jpeg, png, bmp", 'error');
          this.myInputVariable.nativeElement.value = "";
        }
         

      //  }
      };
      reader.readAsDataURL(files[i]);
    }
    Swal.close();
    
  
  }

  Upload() {

    if (this.claimsDocument.value.DocumentType !== "") {

      this.rows = [];
      if (this.base64filecount == this.UploadDocumentfile.length) {
        this.apiClaimAction.UploadFile(this.UploadDocumentfile).subscribe((response: {}) => {

          this.DocumentListrows = response;
          if (this.DocumentListrows.length > 0) {

            for (let i = 0; i < this.DocumentListrows.length; i++) {
              this.DocumentListDatas.push({ "id": this.DocumentListrows[i].id, "ext": this.DocumentListrows[i].ext, "fileName": this.DocumentListrows[i].fileName, "fileUrl": this.DocumentListrows[i].fileUrl, "dateCreated": this.DocumentListrows[i].dateCreated, "documentType": this.DocumentListrows[i].documentType, "base64file": this.DocumentListrows[i].base64file })
            }
            this.rows = this.DocumentListDatas;
            console.log(this.rows);

            Swal.fire('Thanks', "File Uploaded successfully", 'success');
          } else {
            Swal.fire('sorry', "no file Uploaded", 'error');
          }

        });
      }
    } else {
      Swal.fire('sorry', "kindly select document type", 'error');
    }
   
  }


  Delete(rowval) {

    Swal.fire({
      title: 'Are you sure',
      text: "You want to delete this file!",
      icon: 'warning',
      showCancelButton: true,
      confirmButtonColor: '#3085d6',
      cancelButtonColor: '#d33',
      confirmButtonText: 'Yes, delete it!'
    }).then((result) => {
      if (result.isConfirmed) {

        Swal.fire('Please wait', "Deleting file in progress", 'warning');
        Swal.showLoading();

        this.apiClaimAction.DeleteFile(rowval.fileUrl).subscribe((response: {}) => {

          if (response == true) {
            this.DocumentListDatas.splice(rowval.id, 1);
            Swal.fire('Ok', "File Deleted Successfully", 'success');
          }
          else {
            Swal.fire('Ok', "Operation failed while Deleting a file ", 'error');
          }


        });
      }
    })
 
  //  this.DocumentListDatas.filter()
  }

  valuewin: string;
  Openfile(rowval) {
   // window.open(rowval.base64file, "Document", "width=500,height=500,scrollbars=yes", true);
    if (rowval.ext == "pdf") {
      const linkSource = rowval.base64file;
      const downloadLink = document.createElement("a");
      const fileName = rowval.fileName+".pdf";

      downloadLink.href = linkSource;
      downloadLink.download = fileName;
      downloadLink.click();
    
      
    //  window.open(rowval.base64file, "Document", "width=500,height=500,scrollbars=yes", true);
    } else {
      var image = new Image();
      image.src = rowval.base64file;
      var w = window.open("");
      w.document.write(image.outerHTML);
    }
}

}




