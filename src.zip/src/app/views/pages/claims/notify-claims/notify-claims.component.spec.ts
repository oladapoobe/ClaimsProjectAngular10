import { ComponentFixture, TestBed } from '@angular/core/testing';

import { NotifyClaimComponent } from './notify-claims.component';

describe('NotifyClaims', () => {
  let component: NotifyClaimComponent;
  let fixture: ComponentFixture<NotifyClaimComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ NotifyClaimComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(NotifyClaimComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
