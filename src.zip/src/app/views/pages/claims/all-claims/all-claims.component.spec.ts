import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AllClaimComponent } from './all-claims.component';

describe('AllClaimComponent', () => {
  let component: AllClaimComponent;
  let fixture: ComponentFixture<AllClaimComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AllClaimComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(AllClaimComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
