import { Component, OnInit } from '@angular/core';
import { ClaimsService } from 'src/app/service/claims-service/claims.service';
import { ColumnMode } from '@swimlane/ngx-datatable';
import Swal from 'sweetalert2/dist/sweetalert2.js';
import { NgbDateStruct } from '@ng-bootstrap/ng-bootstrap';

@Component({
  selector: 'app-all-claims',
  templateUrl: './all-claims.component.html',
  styleUrls: ['./all-claims.component.scss']
})
export class AllClaimComponent implements OnInit {

  selectedDate: NgbDateStruct;
  ColumnMode = ColumnMode;
  loadingIndicator = true;
  reorderable = true;  
  rows: any = [];
  constructor(public ApiClaimAction: ClaimsService) { }
  ngOnInit(): void {
    this.viewAllClaims();
  }

  viewAllClaims(){
    Swal.fire('Please wait', "geting claims record in progress", 'warning')
    Swal.showLoading();
   // this.ApiClaimAction.getAll().subscribe((data: {}) => {
    //  this.rows = data;
    //   Swal.close();
   //  });

    Swal.close();
  }
}
