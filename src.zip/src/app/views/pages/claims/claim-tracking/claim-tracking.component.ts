import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-claims-tracking',
  templateUrl: './claim-tracking.component.html',
  styleUrls: ['./claim-tracking.component.scss']
})
export class ClaimTrackingComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
