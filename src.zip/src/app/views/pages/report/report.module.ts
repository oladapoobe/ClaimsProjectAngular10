import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Routes, RouterModule } from '@angular/router';
import { ReportComponent } from './report.component';
import {ClaimStatisticComponent} from './claim-statistic/claim-statistic.component';
import {ClaimTATReportComponents} from './claim-tat-report/claim-tat-report.component';
import { ClaimTrackerComponent } from './claim-tracker/claim-tracker.component';
import { CompletedClaimReportComponent } from './completed-claim-report/completed-claim-report.component';

const routes: Routes = [
  {
    path: '',
    component: ReportComponent,
    children: [
      {
        path: '',
        redirectTo: 'claimstatistic',
        pathMatch: 'full'
      },
      {
        path: 'claimstatistic',
        component: ClaimStatisticComponent
      },
      {
        path:'claimtatreport',
        component:ClaimTATReportComponents
      },
      {
        path:'claimtracker',
        component:ClaimTrackerComponent
      },
      {
        path:'completedclaimreport',
        component:CompletedClaimReportComponent
      }
    ]
  },
]

@NgModule({
  declarations: [ReportComponent, ClaimStatisticComponent, ClaimTATReportComponents, ClaimTrackerComponent, CompletedClaimReportComponent],
  imports: [
    CommonModule,
    RouterModule.forChild(routes)
  ]
})
export class ReportModule { }