import { Component, OnInit } from '@angular/core';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';

@Component({
  selector: 'app-claim-tat-report',
  templateUrl: './claim-tat-report.component.html',
  styleUrls: ['./claim-tat-report.component.scss']
})
export class ClaimTATReportComponents implements OnInit {

   constructor(private modalService: NgbModal) { }

  ngOnInit(): void {
  }

  openLgModal(content) {
    this.modalService.open(content, {size: 'lg'}).result.then((result) => {
      
    }).catch((res) => {});
  }

}
