import { Component, OnInit } from '@angular/core';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';

@Component({
  selector: 'app-completed-claim',
  templateUrl: './completed-claim-report.component.html',
  styleUrls: ['./completed-claim-report.component.scss']
})
export class CompletedClaimReportComponent implements OnInit {

   constructor(private modalService: NgbModal) { }

  ngOnInit(): void {
  }

  openLgModal(content) {
    this.modalService.open(content, {size: 'lg'}).result.then((result) => {
      
    }).catch((res) => {});
  }

}
