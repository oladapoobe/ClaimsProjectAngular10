import { ComponentFixture, TestBed } from '@angular/core/testing';
import { CompletedClaimReportComponent } from './completed-claim-report.component';

describe('CompletedClaimReportComponent', () => {
  let component: CompletedClaimReportComponent;
  let fixture: ComponentFixture<CompletedClaimReportComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ CompletedClaimReportComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(CompletedClaimReportComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
