import { ComponentFixture, TestBed } from '@angular/core/testing';

import { EscalationManagementComponent } from './escalation-management.component';

describe('EscalationManagementComponent', () => {
  let component: EscalationManagementComponent;
  let fixture: ComponentFixture<EscalationManagementComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ EscalationManagementComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(EscalationManagementComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
