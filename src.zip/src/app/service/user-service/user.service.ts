import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { User } from 'src/app/model/user';
import { UserResponse, VerifiedUser } from 'src/app/model/user';
import { Observable, throwError } from 'rxjs';
import { retry, catchError } from 'rxjs/operators';
import { environment } from 'src/environments/environment';
import { Response } from 'src/app/model/Response';
import Swal from 'sweetalert2/dist/sweetalert2.js';

@Injectable({
  providedIn: 'root'
})
export class UserService {

  private readonly apiURL = `${environment.apiUrl}api/User`;
  private readonly apiURL2 = `${environment.apiUrl}api/Account`;

  constructor(private http: HttpClient) { }

  // HttpClient API put() method => 
  verify(username): Observable<VerifiedUser> {
    return this.http.get<VerifiedUser>(this.apiURL2 + '/get-ad-user-details-by-username/?username=' + username)
      .pipe(
        catchError(this.handleError)
      )
  }

  // HttpClient API get() method =>
  getAll(): Observable<UserResponse> {
    return this.http.get<UserResponse>(this.apiURL + '/get-all')
      .pipe(
        retry(1),
        catchError(this.handleError)
      )
  }

  // HttpClient API get() method =>
  getByID(id): Observable<User> {
    return this.http.get<User>(this.apiURL + '/user-by-id/' + id)
      .pipe(
        retry(1),
        catchError(this.handleError)
      )
  }

  // HttpClient API post() method => 
  create(data): Observable<Response> {
    return this.http.post<Response>(this.apiURL + '/post-create', data)
      .pipe(
      
        catchError(this.handleError)
      )
  }

  // HttpClient API put() method => 
  update(id, data): Observable<Response> {
    return this.http.put<Response>(this.apiURL + '/put-update/' + id, JSON.stringify(data))
      .pipe(
      
        catchError(this.handleError)
      )
  }

  // HttpClient API delete() method => 
  delete(id) {
    return this.http.delete<Response>(this.apiURL + '/put-delete/' + id, )
      .pipe(
      
        catchError(this.handleError)
      )
  }

  // Error handling 
  handleError(error) {
    let errorMessage = '';
    if (error.error instanceof ErrorEvent) {
      // Get client-side error
      errorMessage = error.error.message;
    } else {
      // Get server-side error

      errorMessage = `Error Code: ${error.status}\nMessage: ${error.message}`;
    }
    Swal.fire('Please wait', 'Error in connecting to server, please contact Technology', 'error')

    return throwError(errorMessage);
  }

}
