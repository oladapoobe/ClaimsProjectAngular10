
import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { User } from 'src/app/model/user';
import { RequestUser } from 'src/app/model/user';
import { Role } from 'src/app/model/role';
import { Observable, throwError } from 'rxjs';
import { retry, catchError } from 'rxjs/operators';
import { environment } from 'src/environments/environment';
import { Response } from 'src/app/model/Response';
import Swal from 'sweetalert2/dist/sweetalert2.js';

@Injectable({
  providedIn: 'root'
})
export class RoleService {

  private readonly apiURL = `${environment.apiUrl}api/Role`;


  constructor(private http: HttpClient) { }


  // HttpClient API get() method =>
  getAll(): Observable<Role> {
    return this.http.get<Role>(this.apiURL + '/get-all')
      .pipe(
        retry(1),
        catchError(this.handleError)
      )
  }

  // HttpClient API get() method =>
  getByID(id): Observable<Role> {
    return this.http.get<Role>(this.apiURL + '/role-by-id/' + id)
      .pipe(
        retry(1),
        catchError(this.handleError)
      )
  }

  // HttpClient API post() method => 
  create(data): Observable<Response> {
    return this.http.post<Response>(this.apiURL + '/post-create', JSON.stringify(data))
      .pipe(

        catchError(this.handleError)
      )
  }

  // HttpClient API put() method => 
  update(id, data): Observable<Response> {
    return this.http.put<Response>(this.apiURL + '/put-update/' + id, JSON.stringify(data))
      .pipe(

        catchError(this.handleError)
      )
  }

  // HttpClient API delete() method => 
  delete(id) {
    return this.http.delete<Response>(this.apiURL + '/put-delete/' + id,)
      .pipe(

        catchError(this.handleError)
      )
  }

  // Error handling 
  handleError(error) {
    let errorMessage = '';
    if (error.error instanceof ErrorEvent) {
      // Get client-side error
      errorMessage = error.error.message;
    } else {
      // Get server-side error

      errorMessage = `Error Code: ${error.status}\nMessage: ${error.message}`;
    }
    Swal.fire('Please wait', 'Error in connecting to server, please contact Technology', 'error')

    return throwError(errorMessage);
  }

}
